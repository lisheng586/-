<?php
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyCVkRcSiF0KmLCwmoo4edtw0vnSykCvFcc');
define('GJ_CODE', 'US');
define('SITE_NAME', 'y2b');
define('TITLENAME', 'y2b');
define('EN2DEKEY', '32123wwerwer323tgfdgds');
define('EMAIL', '1334347212@qq.com');
define('NAME', 'admin');
define('PASSWORD', 'admin');
define('LOGINHTML', '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="Login.css"/>
</head>
<body>
<center>
    <p id="login">
    <h1>µÇÂ½</h1>
    <form method="post" style="margin:0px auto;">
        <input type="text" required="required" placeholder="ÓÃ»§Ãû" name="name"></input>
        <br>
        <input type="password" required="required" placeholder="ÃÜÂë" name="password"></input>
        <button class="but" type="submit">µÇÂ¼</button>
    </form>
    </p>
</center>
</body>
</html>');
?>
